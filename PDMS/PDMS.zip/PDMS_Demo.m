function [] = PDMS_Demo()
% Pixel-level Discrete Multiobjective Sampling Demo
% Yihui Liang, IAIS, SCUT
% 2019.07.20
% This demo implements the PDMS-based (pixel-level discrete
% multiobjective sampling) matting algorithm. Notice that preprocessing and
% postprocessing are not applied in this demo.
% Reference: Huang H, Liang Y*, Yang X, et al. Pixel-level Discrete
% Multiobjective Sampling for Image Matting[J]. IEEE Transactions on Image
% Processing, 27(8):3739-3751

clear,close all;

%% Load image and trimap
raw_img = imread('GT13.png');
trimap = imread('trimap.png');



%% Pixel-level Discrete Multiobjective Sampling
%feature
U_ind = find(trimap ==128);
F_ind = find(trimap ==255);
B_ind = find(trimap ==0);
img = reshape(raw_img,numel(trimap),3);
F_color = img(F_ind,:);
B_color = img(B_ind,:);

[y_map,x_map] = ind2sub(size(trimap),1:numel(trimap));
F_corrdinate = [x_map(F_ind)',y_map(F_ind)'];
B_corrdinate = [x_map(B_ind)',y_map(B_ind)'];

[y,x] = ind2sub(size(trimap),1:numel(trimap));
U_alpha = zeros(length(U_ind),1);
for n = 1:length(U_ind)
    U_color = single(img(U_ind(n),:));
    %foreground color sampling
    spatial_cost_FU = pdist2([x(F_ind)',y(F_ind)'],[x(U_ind(n)),y(U_ind(n))]);
    color_cost_FU = pdist2(single(img(F_ind,:)),single(img(U_ind(n),:)));
    pareto_F_bw = FDMO_c([spatial_cost_FU,color_cost_FU]);
    %background color sampling
    spatial_cost_BU = pdist2([x(B_ind)',y(B_ind)'],[x(U_ind(n)),y(U_ind(n))]);
    color_cost_BU = pdist2(single(img(B_ind,:)),single(img(U_ind(n),:)));
    pareto_B_bw = FDMO_c([spatial_cost_BU,color_cost_BU]);
    %sample feature extration
    F_pareto_color = single(F_color(pareto_F_bw,:)');
    B_pareto_color = single(B_color(pareto_B_bw,:)');
    F_pareto_dist = spatial_cost_FU(pareto_F_bw);
    B_pareto_dist = spatial_cost_BU(pareto_B_bw);
    %evaluation and alpha estimation
    U_alpha(n) = EvaluateSamples(pareto_F_bw,pareto_B_bw,...
        F_pareto_color,B_pareto_color,F_pareto_dist,B_pareto_dist,U_color);
end

alpha = trimap;
alpha(U_ind) = U_alpha;
imshow(alpha);
end
%  Fast Discrete Multiobjective Optimization Function
%Input:an array of all feasible solutions of the MOP denoted as C
%Output:C,i(the first i-1 elements in array C is Pareto optimal.In a row as
%a combination of solutions) and pareto_front_bw (the binary vector that
%indicates the Pareto front)
function[pareto_front_bw,C,i] = FDMO(C)
i=1;
j=size(C,1);
solution_ind = 1:size(C,1);
while(i<=j)
    cmp=i+1;
    while(cmp<=j)
        if( all(C(i,:)<=C(cmp,:))&&any(C(i,:)<C(cmp,:)) )
            solution_ind([j,cmp])=solution_ind([cmp,j]);
            C([j,cmp],:)=C([cmp,j],:);
            j=j-1;
        elseif(all(C(cmp,:)<=C(i,:))&&any(C(cmp,:)<C(i,:)))
            C([i,cmp,j],:)=C([cmp,j,i],:);
            solution_ind([i,cmp,j])=solution_ind([cmp,j,i]);
            j=j-1;
            cmp=i+1;
        else
            cmp=cmp+1;
        end
    end
    i=i+1;
end
pareto_front_bw = false(size(C,1),1);
pareto_front_bw(solution_ind(1:i-1)) = 1;
end