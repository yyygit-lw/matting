# DIM_evaluation_code_python

- A **python** version of the **Matlab** Deep Image Matting evaluation code provided by **[Deep Image Matting](https://sites.google.com/view/deepimagematting)**.

- Tested on our local data set shows that python version is almost consistent with Matlab version, with an error of less than 0.001.

- Usage can refer to 'evaluate.py'.